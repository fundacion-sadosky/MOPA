import 'dart:async';

import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';

import 'ble_device_interactor.dart';
import 'ble_logger.dart';
import 'ble_scanner.dart';

class BloodPressureDeviceHandler {

  final _ble = FlutterReactiveBle();
  final _bleLogger = BleLogger();
  final int SYST_INDEX = 1;
  final int DIAS_INDEX = 2;
  final int PULSE_INDEX = 3;
  final int REG_ID = 129;

  late final _serviceDiscoverer = BleDeviceInteractor(
    bleDiscoverServices: _ble.discoverServices,
    readCharacteristic: _ble.readCharacteristic,
    writeWithResponse: _ble.writeCharacteristicWithResponse,
    writeWithOutResponse: _ble.writeCharacteristicWithoutResponse,
    subscribeToCharacteristic: _ble.subscribeToCharacteristic,
    logMessage: _bleLogger.addToLog,);


  late QualifiedCharacteristic characteristic;
  DiscoveredDevice? device;

  late StreamController<BloodPressureData> bloodPressureDataUpdateController;

  late StreamController<ConnectionStateUpdate> conStateStreamController;

  late StreamSubscription<List<int>> serviceDiscovererStream;

  late StreamSubscription connectionSubscription;

  bool _stopScan = false;

  BloodPressureDeviceHandler();

  set stopScan(bool value) => _stopScan = value;

  /**This method is to find the id of the yonker device. Yonker name is
   * set in @BleScanner class*/
  Future<DiscoveredDevice?> _discoverYonker() async {
    BleScanner scanner = BleScanner(ble: _ble, logMessage: _bleLogger.addToLog);
    scanner.startScan([],"YK-BPA2");

    await for (var elem in scanner.state) {
      if (elem.discoveredDevices.isNotEmpty) {
        device = elem.discoveredDevices.first;
      }
      if (device != null || _stopScan ) {
        scanner.stopScan();
        return device;
      }
    }
  }

  void monitorConnectionToYonker() async{
    this.device = await _discoverYonker();
    //uncomment for debugging purposes
    print("Hey I discovered a Yonker BloodPressureMonitor device with the Id ${device!.id}");

    if (device != null)
      connectionSubscription = _ble.connectToDevice(id: device!.id,
                                connectionTimeout: const Duration(seconds: 4),
      ).listen((event) {
        print("ConnStateUpdate: "+ event.connectionState.name);
        if (!conStateStreamController.isClosed) {
          conStateStreamController.add(event);
        }
      });
  }


  void _suscribeToYonkerUpdates(){
    characteristic = QualifiedCharacteristic(characteristicId: Uuid.parse("cdeacd81-5235-4c07-8846-93a37ee6b86d"), serviceId:Uuid.parse("CDEACD80-5235-4C07-8846-93A37EE6B86D"), deviceId: device!.id);
    serviceDiscovererStream = _serviceDiscoverer.subScribeToCharacteristic(characteristic).listen((
        event) {

      if (event.isNotEmpty && event.first == REG_ID) {
        if (!bloodPressureDataUpdateController.isClosed) {
          bloodPressureDataUpdateController.add(BloodPressureData(
              event.elementAt(SYST_INDEX), event.elementAt(DIAS_INDEX), event.elementAt(PULSE_INDEX)));
          //uncomment for debugging purposes
          //print("oxigen value: ${event.elementAt(SpO2INDEX)}");
          //print("heartrate value: ${event.elementAt(HRINDEX)}");
        }
        }
    });
  }

  Stream suscribeToConnectionState() {
    conStateStreamController = StreamController<ConnectionStateUpdate>();
    return conStateStreamController.stream;
  }

  Stream suscribeToBloodPressureDataUpdates() {
    bloodPressureDataUpdateController = StreamController<BloodPressureData>();
    _suscribeToYonkerUpdates();
    return bloodPressureDataUpdateController.stream;
  }

  Future<bool> disconnectFromDevice() async{
    await bloodPressureDataUpdateController.close();
    await conStateStreamController.close();
    serviceDiscovererStream.cancel();
    connectionSubscription.cancel();
    return conStateStreamController.isClosed;
  }

}

class BloodPressureData {

  final int _systolic_pressure;

  final int _diastolic_pressure;
  
  final int _pulse;

  BloodPressureData(this._systolic_pressure, this._diastolic_pressure, this._pulse);

  int get systolic_pressure => _systolic_pressure;
  int get diastolic_pressure => _diastolic_pressure;
  int get pulse => _pulse;

}

