abstract class ReactiveState<T> {
  Stream<T> get state;
}
