package com.virtualsense.bpm_yonker_sdk;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
