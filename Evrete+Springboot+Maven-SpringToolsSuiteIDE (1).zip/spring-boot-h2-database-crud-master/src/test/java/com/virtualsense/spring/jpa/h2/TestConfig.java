package com.virtualsense.spring.jpa.h2;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.virtualsense.spring"})
public class TestConfig {
	
}
