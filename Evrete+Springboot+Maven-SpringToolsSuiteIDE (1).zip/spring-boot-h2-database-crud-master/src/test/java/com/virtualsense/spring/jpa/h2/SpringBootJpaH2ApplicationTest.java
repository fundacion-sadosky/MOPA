package com.virtualsense.spring.jpa.h2;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.virtualsense.spring.jpa.evrete.EvreteConfiguration;
import com.virtualsense.spring.jpa.h2.SpringBootJpaH2Application;
import com.virtualsense.spring.jpa.h2.dto.DeviceDTO;
import com.virtualsense.spring.jpa.h2.dto.ObservationDTO;
import com.virtualsense.spring.jpa.h2.dto.PatientDTO;
import com.virtualsense.spring.jpa.h2.model.DeviceType;
import com.virtualsense.spring.jpa.h2.model.IdentityDocumentType;
import com.virtualsense.spring.jpa.h2.service.ServiceFacade;

@ContextConfiguration(classes = TestConfig.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class SpringBootJpaH2ApplicationTest {

	@LocalServerPort
	private Integer port;
	 
	@Autowired
	private TestRestTemplate testRestTemplate;
	 
	@Test
	void accessApplication() {
		System.out.println(port);
	}
	
	@Test
	public void test1() throws Exception {
		DeviceDTO deviceDTO = new DeviceDTO(1, "OKOK International", DeviceType.SCALE);
		PatientDTO patientDTO = new PatientDTO(33333333, IdentityDocumentType.DNI, "Juan", "Perez", null);
		ObservationDTO obs = new ObservationDTO(0, deviceDTO, patientDTO, new Date(), 80.0);
		/**
		 * @TODO Usar testRestTemplate para invocar el endpoint 
		 * POST
		 * http://localhost:port/api/observations
		 */
	}

}
