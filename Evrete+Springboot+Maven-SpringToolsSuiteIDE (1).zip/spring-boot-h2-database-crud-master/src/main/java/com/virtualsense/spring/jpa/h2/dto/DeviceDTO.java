package com.virtualsense.spring.jpa.h2.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.virtualsense.spring.jpa.h2.model.DeviceType;

@JsonPropertyOrder({"id", "type", "brand"})
public class DeviceDTO {
	@JsonProperty
	long id;
	@JsonProperty
	String brand;
	DeviceType type;

	public DeviceDTO(long id, String brand, DeviceType type) {
		this.id = id; 
		this.brand = brand;
		this.type = type;
	}
	
	public DeviceDTO(long id, String brand, String type) {
		this.id = id; 
		this.brand = brand;
		this.type = decodeType(type);
	}

	@JsonProperty
	public String getType() {
		return type.toString().toLowerCase();
	}
	
	private DeviceType decodeType(String typeStr) {
		return DeviceType.valueOf(typeStr.toUpperCase());
	}
	
	public long getId() {
		return id; 
	}
	
	public String getBrand() {
		return brand;
	}
	
}
