package com.virtualsense.spring.jpa.h2.repository;

import com.virtualsense.spring.jpa.h2.model.Device;
import com.virtualsense.spring.jpa.h2.model.DeviceType;
import com.virtualsense.spring.jpa.h2.model.IdentityDocumentType;
import com.virtualsense.spring.jpa.h2.model.NationalIdentityDocument;
import com.virtualsense.spring.jpa.h2.model.Observation;
import com.virtualsense.spring.jpa.h2.model.Patient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.history.Revision;
import org.springframework.data.history.Revisions;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Iterator;

@Component
public class RepositoryFiller implements CommandLineRunner {

    @Autowired
    DeviceRepository deviceRepository;

    @Autowired
    ObservationRepository observationRepository;
  
    @Autowired
    PatientRepository patientRepository;
    
    @Override
    public void run(String... args) throws Exception {
    	
    	Device scaleDevice = new Device(DeviceType.SCALE, "OKOK International");
		  deviceRepository.save(scaleDevice);
		  deviceRepository.save(new Device(DeviceType.ECG, "WeCardio"));
		  deviceRepository.save(new Device(DeviceType.TENSIOMETER, "Joytech Healthcare"));
		  deviceRepository.save(new Device(DeviceType.TENSIOMETER, "YonkerCare"));
		  deviceRepository.save(new Device(DeviceType.PULSIOXIMETER, "YonkerCare"));

		  Patient observedPatient = new Patient(new NationalIdentityDocument(33333333, IdentityDocumentType.DNI), "Juan", "Perez", null);
		  patientRepository.save(observedPatient);
		  patientRepository.save(new Patient(new NationalIdentityDocument(44444444, IdentityDocumentType.DNI), "Luis", "Gonzalez", null));
		  patientRepository.save(new Patient(new NationalIdentityDocument(22222222, IdentityDocumentType.LC), "Norma", "Simpson", null));
		  patientRepository.save(new Patient(new NationalIdentityDocument(11111111, IdentityDocumentType.LE), "Nestor", "Simpson", null));

		  String pattern = "yyyy-MM-dd";
		  SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-14"), 80.0));
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-13"), 80.0));
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-12"), 79.5));
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-11"), 79.0));
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-10"), 79.0));
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-09"), 79.0));
		  observationRepository.save(new Observation(scaleDevice, observedPatient, simpleDateFormat.parse("2023-06-08"), 79.0));
		  
		  observedPatient.setBirthDate(simpleDateFormat.parse("1949-10-20"));
		  patientRepository.save(observedPatient);
		  
		  Revisions<Long, Patient> revisions = patientRepository.findRevisions(observedPatient.getId());
		  Iterator<Revision<Long, Patient>> revisionIterator = revisions.iterator();
		  while (revisionIterator.hasNext()) {
			  // We can manipulate Revision objects as needed
			  // System.out.println(revisionIterator.next().getEntity().getBirthDate());
		  }
		  
    }
}
