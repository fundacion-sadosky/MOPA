package com.virtualsense.spring.jpa.h2.model;

public enum DeviceType
{
    SCALE, ECG, PULSIOXIMETER, TENSIOMETER
}

