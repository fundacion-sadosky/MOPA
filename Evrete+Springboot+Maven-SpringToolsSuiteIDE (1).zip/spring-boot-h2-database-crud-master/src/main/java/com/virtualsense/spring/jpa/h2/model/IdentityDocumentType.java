package com.virtualsense.spring.jpa.h2.model;

public enum IdentityDocumentType
{
    LE, LC, DNI
}

