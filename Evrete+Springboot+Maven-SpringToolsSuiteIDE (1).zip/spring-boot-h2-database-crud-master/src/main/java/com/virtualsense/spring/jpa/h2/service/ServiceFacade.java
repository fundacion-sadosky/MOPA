package com.virtualsense.spring.jpa.h2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.virtualsense.spring.jpa.evrete.KnowledgeBaseBean;
import com.virtualsense.spring.jpa.h2.dto.DeviceDTO;
import com.virtualsense.spring.jpa.h2.dto.ObservationDTO;
import com.virtualsense.spring.jpa.h2.dto.PatientDTO;
import com.virtualsense.spring.jpa.h2.model.Device;
import com.virtualsense.spring.jpa.h2.model.DeviceType;
import com.virtualsense.spring.jpa.h2.model.IdentityDocumentType;
import com.virtualsense.spring.jpa.h2.model.NationalIdentityDocument;
import com.virtualsense.spring.jpa.h2.model.Observation;
import com.virtualsense.spring.jpa.h2.model.Patient;
import com.virtualsense.spring.jpa.h2.repository.DeviceRepository;
import com.virtualsense.spring.jpa.h2.repository.ObservationRepository;
import com.virtualsense.spring.jpa.h2.repository.PatientRepository;

import jakarta.annotation.PostConstruct;

@Service
public class ServiceFacade {

	  @Autowired
	  DeviceRepository deviceRepository;

	  @Autowired
	  ObservationRepository observationRepository;
	  
	  @Autowired
	  PatientRepository patientRepository;
	  
	  KnowledgeBaseBean knowledgeBase;

	  @Autowired
	  @Lazy
	  void setKnowledge(KnowledgeBaseBean knowledgeBase) {
		  this.knowledgeBase = knowledgeBase;
	  }
	  
	  public KnowledgeBaseBean getKnowledge() {
		  return knowledgeBase;
	  }

	  @PostConstruct
	  public void init() throws Exception {
	  }
	  
	  public List<DeviceDTO> getAllDevices() {
	      List<DeviceDTO> devices = new ArrayList<DeviceDTO>();
	      deviceRepository.findAll().forEach((device) -> { 
	    	devices.add(new DeviceDTO(device.getId(), device.getBrand(), device.getType()));
	      });
	      return devices;
	  }

	  public List<DeviceDTO> getAllDevicesByType(DeviceType type) {
			List<DeviceDTO> devices = new ArrayList<DeviceDTO>();
			deviceRepository.findByType(type).forEach((device) -> {
		    	devices.add(new DeviceDTO(device.getId(), device.getBrand(), device.getType()));
			});
			return devices;
	  }

	  public List<DeviceDTO> getAllDevicesByBrand(String brand) {
			List<DeviceDTO> devices = new ArrayList<DeviceDTO>();
			deviceRepository.findByBrandContainingIgnoreCase(brand).forEach((device) -> {
		    	devices.add(new DeviceDTO(device.getId(), device.getBrand(), device.getType()));
			});
			return devices;
	  }
	  
	  private PatientDTO mapToDTO(Optional<Patient> patient) {
		  if (patient.isPresent()) {
			  Patient data = patient.get();
			  return new PatientDTO(data.getId().getDocumentNumber(), data.getId().getDocumentType(), data.getFirstName(), data.getLastName(), data.getBirthDate());
		  }
		  return null;
	  }
	  
	  public Optional<PatientDTO> findPatientById(long number, IdentityDocumentType type) {
			NationalIdentityDocument id = new NationalIdentityDocument(number, type);
			Optional<Patient> patient = patientRepository.findById(id);
			return Optional.ofNullable(mapToDTO(patient));
	  }
	  
	  public List<PatientDTO> findAllPatients() {
	      List<PatientDTO> patients = new ArrayList<PatientDTO>();
	      patientRepository.findAll().forEach((data) -> {
			  patients.add(new PatientDTO(data.getId().getDocumentNumber(), data.getId().getDocumentType(), data.getFirstName(), data.getLastName(), data.getBirthDate()));
	      });
	      return patients;
	  }
	  
	  public List<ObservationDTO> findAllObservations() {
		  List<ObservationDTO> obs = new ArrayList<ObservationDTO>();
		  observationRepository.findAll(Sort.by("patient.lastName").ascending()).forEach((o) -> {
			  DeviceDTO ddto = new DeviceDTO(o.getDevice().getId(), o.getDevice().getBrand(), o.getDevice().getType());
			  Patient pdao = o.getPatient();
			  PatientDTO pdto = new PatientDTO(pdao.getId().getDocumentNumber(), pdao.getId().getDocumentType(), pdao.getLastName(), pdao.getLastName(), pdao.getBirthDate());
			  obs.add(new ObservationDTO(o.getId(), ddto, pdto, o.getObservationDate(), o.getObservationValue()));
		  });
		  return obs;
	  }
	  
	  public Optional<ObservationDTO> createObservation(ObservationDTO obs) {
		  DeviceType dType = DeviceType.valueOf(obs.getDevice().getType().toUpperCase());
		  Device device = new Device(obs.getDevice().getId(), dType, obs.getDevice().getBrand());
		  IdentityDocumentType docEnumType = IdentityDocumentType.valueOf(obs.getPatient().getDocumentType().toUpperCase());
		  NationalIdentityDocument doc = new NationalIdentityDocument(obs.getPatient().getId(), docEnumType);
		  Patient patient = new Patient(doc, obs.getPatient().getFirstName(), obs.getPatient().getLastName(), obs.getPatient().getBirthDate());
		  Observation newObservation = observationRepository.save(new Observation(device, patient, obs.getObservationDate(), obs.getObservationValue()));

		  getKnowledge().evaluateRules(newObservation);
		  ObservationDTO result = new ObservationDTO(newObservation.getId(), obs.getDevice(), obs.getPatient(), obs.getObservationDate(), obs.getObservationValue());
		  /**
		   * TODO Transactional support
		   * If rollback is performed, return an empty optional
		   */
		  return Optional.of(result);
	  }
	  
}
