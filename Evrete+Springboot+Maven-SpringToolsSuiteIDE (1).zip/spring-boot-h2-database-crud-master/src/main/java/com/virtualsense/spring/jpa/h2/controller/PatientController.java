package com.virtualsense.spring.jpa.h2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.virtualsense.spring.jpa.h2.dto.PatientDTO;
import com.virtualsense.spring.jpa.h2.model.IdentityDocumentType;
import com.virtualsense.spring.jpa.h2.service.ServiceFacade;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
/**
 * 
 * @author cmateos
 */
public class PatientController {

  @Autowired
  ServiceFacade facade;
  
  @GetMapping("/patients")
  public ResponseEntity<List<PatientDTO>> getAllPatients() {
    try {
    	List<PatientDTO> patients = facade.findAllPatients();
    	if (patients.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      }
      return new ResponseEntity<>(patients, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

	@GetMapping("/patient")
	public ResponseEntity<PatientDTO> getPatient(@RequestParam(defaultValue="DNI") String documentType, @RequestParam(required=true) long documentNumber) {
		IdentityDocumentType it = null;
		try {
			it = IdentityDocumentType.valueOf(documentType);
		} catch(IllegalArgumentException ex) {
		      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		Optional<PatientDTO> result = facade.findPatientById(documentNumber, it);
		if (result.isPresent()) {
			return new ResponseEntity<PatientDTO>(result.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

}
