package com.virtualsense.spring.jpa.h2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtualsense.spring.jpa.h2.dto.DeviceDTO;
import com.virtualsense.spring.jpa.h2.model.Device;
import com.virtualsense.spring.jpa.h2.model.DeviceType;
import com.virtualsense.spring.jpa.h2.repository.DeviceRepository;
import com.virtualsense.spring.jpa.h2.service.ServiceFacade;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
/**
 * 
 * @author cmateos
 */
public class DeviceController {
	
  @Autowired
  ServiceFacade facade;
  
  @GetMapping("/devices")
  public ResponseEntity<List<DeviceDTO>> getAllDevices() {
    try {
      List<DeviceDTO> devices = facade.getAllDevices();
      if (devices.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      }
      return new ResponseEntity<>(devices, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

	@GetMapping("/devices/types/{type}")
	public ResponseEntity<List<DeviceDTO>> getDevicesByType(@PathVariable("type") String type) {
		DeviceType dt = null;
		try {
			dt = DeviceType.valueOf(type.toUpperCase());
		} catch (IllegalArgumentException ex) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		List<DeviceDTO> devices = facade.getAllDevicesByType(dt);
		if (!devices.isEmpty()) {
			return new ResponseEntity<List<DeviceDTO>>(devices, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

  @GetMapping("/devices/brands/{brand}")
  public ResponseEntity<List<DeviceDTO>> getDevicesByBrand(@PathVariable("brand") String brand) {
	  	List<DeviceDTO> devices = facade.getAllDevicesByBrand(brand);
	    if (!devices.isEmpty()) {
	      return new ResponseEntity<List<DeviceDTO>>(devices, HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
  }

}
