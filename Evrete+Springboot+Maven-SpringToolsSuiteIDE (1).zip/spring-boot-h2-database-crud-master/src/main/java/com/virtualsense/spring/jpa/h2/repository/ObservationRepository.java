package com.virtualsense.spring.jpa.h2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.virtualsense.spring.jpa.h2.model.Device;
import com.virtualsense.spring.jpa.h2.model.Observation;
import com.virtualsense.spring.jpa.h2.model.Patient;

public interface ObservationRepository extends JpaRepository<Observation, Long>, PagingAndSortingRepository<Observation, Long> {

  List<Observation> findAll();
  
  List<Observation> findByPatient(Patient patient);

  List<Observation> findByDevice(Device device);

  @Query(
		"SELECT o FROM Observation as o WHERE o.patient = :patient AND WEEK(NOW()) = WEEK(o.observationDate)")
  List<Observation> findByPatientLastWeek(@Param("patient") Patient patient);

}
