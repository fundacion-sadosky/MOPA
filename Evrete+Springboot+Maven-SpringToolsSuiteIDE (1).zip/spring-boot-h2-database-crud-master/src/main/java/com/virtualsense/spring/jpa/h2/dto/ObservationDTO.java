package com.virtualsense.spring.jpa.h2.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ObservationDTO {
	@JsonProperty
	long id;
	public long getId() {
		return id;
	}

	public PatientDTO getPatient() {
		return patient;
	}

	public Date getObservationDate() {
		return observationDate;
	}

	public double getObservationValue() {
		return observationValue;
	}

	@JsonProperty
	DeviceDTO device; 
	public DeviceDTO getDevice() {
		return device;
	}

	@JsonProperty
	PatientDTO patient;
	@JsonProperty
	Date observationDate;
	@JsonProperty
	double observationValue; 
	
	public ObservationDTO(long id, DeviceDTO device, PatientDTO patient, Date observationDate, double observationValue) {
		this.id = id; 
		this.device = device; 
		this.patient = patient; 
		this.observationDate = observationDate;
		this.observationValue = observationValue;
	}
	
	
	
}
