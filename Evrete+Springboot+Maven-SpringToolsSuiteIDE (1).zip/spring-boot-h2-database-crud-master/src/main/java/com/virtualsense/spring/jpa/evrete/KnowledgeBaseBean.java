package com.virtualsense.spring.jpa.evrete;

import org.evrete.KnowledgeService;
import org.evrete.api.FactHandle;
import org.evrete.api.IntToValue;
import org.evrete.api.Knowledge;
import org.evrete.api.StatelessSession;

import com.virtualsense.spring.jpa.h2.model.IdentityDocumentType;
import com.virtualsense.spring.jpa.h2.model.Observation;
import com.virtualsense.spring.jpa.h2.model.Patient;

public class KnowledgeBaseBean {

	private Knowledge knowledge = null;
			
	public KnowledgeBaseBean() {
		KnowledgeService service = new KnowledgeService();
		knowledge = service
		        .newKnowledge()
		        .newRule()
		        .forEach("$o", Observation.class)
		        .where(this::hasDNI, "$o")
		        .execute(context -> {
		        	Observation obj = context.get("$o");
		        	System.out.println("Observation patient has DNI: " + obj.getPatient().getLastName() + ", " + obj.getPatient().getFirstName());
		        });		
	}
	
	protected boolean hasDNI(IntToValue values) {
		Patient patient = ((Observation)values.get(0)).getPatient();
		return patient.getId().getDocumentType().equals(IdentityDocumentType.DNI);
	}
	
	protected Knowledge getKnowledge() {
		return this.knowledge;
	}
	
	public void evaluateRules(Observation newObs) {
		StatelessSession session = getKnowledge().newStatelessSession();
		FactHandle observationHandle = session.insert(newObs);

		session.fire((handle, object) -> {
			/*
			 * Nothing todo as for now
			 */
		});
		
	}
	
}
