package com.virtualsense.spring.jpa.h2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtualsense.spring.jpa.h2.dto.ObservationDTO;
import com.virtualsense.spring.jpa.h2.service.ServiceFacade;

//@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
@ComponentScan(basePackages = "com.virtualsense.spring.jpa.evrete")
/**
 * 
 * @author cmateos
 * h2 -> http://localhost:8080/h2-ui
 */
public class ObservationController {
  
  @Autowired
  ServiceFacade service;
  
  @GetMapping("/observations")
  public ResponseEntity<List<ObservationDTO>> getAllDevices() {
    try {
      List<ObservationDTO> obs = service.findAllObservations();
      if (obs.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      }
      return new ResponseEntity<>(obs, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }  

  @PostMapping("/observations")
  public ResponseEntity<ObservationDTO> createObservation(@RequestBody ObservationDTO obs) {
    try {
    	Optional<ObservationDTO> result = service.createObservation(obs);
    	if (result.isPresent()) { 
        	return new ResponseEntity<ObservationDTO>(result.get(), HttpStatus.CREATED);
    	}
    	return new ResponseEntity<ObservationDTO>(result.get(), HttpStatus.NO_CONTENT);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}
