package com.virtualsense.spring.jpa.h2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.history.RevisionRepository;

import com.virtualsense.spring.jpa.h2.model.NationalIdentityDocument;
import com.virtualsense.spring.jpa.h2.model.Patient;

public interface PatientRepository extends JpaRepository<Patient, NationalIdentityDocument>, RevisionRepository<Patient, NationalIdentityDocument, Long> {

  List<Patient> findAll();
  
  List<Patient> findByLastNameContainingIgnoreCase(String lastName);
  
}
