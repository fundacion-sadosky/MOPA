package com.virtualsense.spring.jpa.h2.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "observations")
public class Observation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@JoinColumn(name = "device_id")
	@ManyToOne
	private Device device; 
	
    @ManyToOne(fetch = FetchType.EAGER)
	private Patient patient;
	
	@Column
	private Date observationDate;

	@Column
	private double observationValue; 
	
	public Observation() {
		this.observationDate = new Date();
		this.observationValue = 0.0;
	}
	
	public Observation(Device device, Patient patient, Date observationDate, double observationValue) {
		this.device = device; 
		this.patient = patient;
		this.observationDate = observationDate;
		this.observationValue = observationValue;
	}
	
	public long getId() {
		return id;
	}

	public Device getDevice() {
		return device;
	}

	public Patient getPatient() {
		return patient;
	}

	public Date getObservationDate() {
		return observationDate;
	}
	
	public double getObservationValue() {
		return observationValue;
	}
	
	public String toString() {
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		String patientFullName = getPatient().getFirstName() + " " + getPatient().getLastName();
		return "[Observation] " + patientFullName + " " + format.format(getObservationDate());				
	}
	
}
