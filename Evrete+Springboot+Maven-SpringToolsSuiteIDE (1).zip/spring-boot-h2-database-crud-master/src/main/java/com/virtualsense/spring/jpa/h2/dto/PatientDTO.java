package com.virtualsense.spring.jpa.h2.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.virtualsense.spring.jpa.h2.model.IdentityDocumentType;

public class PatientDTO {
		@JsonProperty
		long id;
		private IdentityDocumentType documentType;
		String firstName;
		String lastName;
		Date birthDate;

		public PatientDTO(long id, IdentityDocumentType documentType, String firstName, String lastName, Date birthDate) {
			this.id = id; 
			this.documentType = documentType;
			this.firstName = firstName;
			this.lastName = lastName;
			this.birthDate = birthDate;
		}

		public PatientDTO(long id, String documentType, String firstName, String lastName, Date birthDate) {
			this.id = id; 
			this.documentType = decodeDocumentType(documentType);
			this.firstName = firstName;
			this.lastName = lastName;
			this.birthDate = birthDate;
		}

		@JsonProperty
		public String getDocumentType() {
			return documentType.toString().toLowerCase();
		}

		public long getId() {
			return this.id;
		}
		
		public IdentityDocumentType decodeDocumentType(String documentType) {
			return IdentityDocumentType.valueOf(documentType.toUpperCase());
		}
		
		public String getFirstName() {
			return this.firstName;
		}

		public String getLastName() {
			return this.lastName;
		}
		
		public Date getBirthDate() {
			return this.birthDate;
		}

}
