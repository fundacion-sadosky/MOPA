package com.virtualsense.spring.jpa.h2.model;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Embeddable;

@Embeddable
public class NationalIdentityDocument {

	private long documentNumber;
	
	public NationalIdentityDocument() {
		this(0, IdentityDocumentType.DNI);
	}
	
	public NationalIdentityDocument(long documentNumber, @Nonnull IdentityDocumentType type) {
		this.documentNumber = documentNumber;
		this.documentType = type;
	}
	
	public long getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(long documentNumber) {
		this.documentNumber = documentNumber;
	}

	public IdentityDocumentType getDocumentType() {
		return documentType;
	}

	public void setDocumentType(IdentityDocumentType documentType) {
		this.documentType = documentType;
	}

	private IdentityDocumentType documentType;
	
}
