package com.virtualsense.spring.jpa.h2.model;

import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "devices")
@Audited
@AuditTable(value = "Audit_devices")
public class Device {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonIgnore
	private long id;

	@Column
	private DeviceType type;
	@Column
	private String brand;

	public Device() {
	}
	
	public Device(@Nonnull DeviceType type, @Nonnull String brand) {
		this.type = type;
		this.brand = brand;
	}
	
	public Device(@Nonnull long id, @Nonnull DeviceType type, @Nonnull String brand) {
		this.id = id;
		this.type = type;
		this.brand = brand;
	}
	
	public long getId() {
		return id;
	}
	public DeviceType getType() {
		return type;
	}
	public String getBrand() {
		return brand;
	}
	
}
