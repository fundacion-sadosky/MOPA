package com.virtualsense.spring.jpa.h2.model;

import java.util.Date;
import java.util.Set;

import org.hibernate.annotations.SQLSelect;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.springframework.data.jpa.repository.Query;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "patients")
@Audited
@AuditTable(value = "Audit_patients")
public class Patient {

	@EmbeddedId
	private NationalIdentityDocument id;
	
	@Column
	private String firstName;
	@Column
	private String lastName;
	@Column
	private Date birthDate;

	@OneToMany(mappedBy="patient", orphanRemoval = false, fetch = FetchType.LAZY)
	@NotAudited
    private Set<Observation> items;
	
	public Patient() {
		this(new NationalIdentityDocument(), "", "", null);
	}
	
	public Patient(@Nonnull NationalIdentityDocument id, @Nonnull String firstName, @Nonnull String lastName, Date birtDate) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthDate = birtDate;
	}
	
	public NationalIdentityDocument getId() {
		return id;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public Set<Observation> getObservations() {
		return items; 
	}
	public void setBirthDate(Date date) {
		this.birthDate = date;
	}
}
