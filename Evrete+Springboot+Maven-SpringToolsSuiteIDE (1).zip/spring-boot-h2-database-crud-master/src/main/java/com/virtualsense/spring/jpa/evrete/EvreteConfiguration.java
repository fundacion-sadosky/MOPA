package com.virtualsense.spring.jpa.evrete;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EvreteConfiguration {

	@Bean
	KnowledgeBaseBean createEvreteBean() {
		return new KnowledgeBaseBean();
	}

}
